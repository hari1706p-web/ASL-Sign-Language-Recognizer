import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Vite config for the ASL recognizer.
// The React plugin gives us JSX fast-refresh in development.
export default defineConfig({
  plugins: [react()],
});
